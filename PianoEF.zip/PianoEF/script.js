document.addEventListener("DOMContentLoaded", () => {
    let secuencia;
    function mostrarLetraNota(nota) {
        const noteDisplay = document.getElementById("noteDisplay");
        noteDisplay.textContent = nota;
        noteDisplay.className = "";

        noteDisplay.classList.add(`note-${nota.toLowerCase()}`);
    }

    function reproducirMusica() {
        const synth = new Tone.Synth().toDestination();

        const notas = ["C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5"];
        secuencia = new Tone.Sequence((tiempo, nota) => {
            synth.triggerAttackRelease(nota, "8n", tiempo);
            mostrarLetraNota(nota);
        }, notas).start(0);

        Tone.Transport.bpm.value = 120;
        Tone.Transport.loop = true;
        Tone.Transport.loopEnd = "4m";
        Tone.Transport.start();

        setTimeout(() => {
            detenerMusica();
        }, 10000);
    }

    function detenerMusica() {
        Tone.Transport.stop();
    }

    const playButton = document.getElementById("playButton");
    playButton.addEventListener("click", reproducirMusica);
});

function reproducirNota(nota) {
    const synth = new Tone.Synth().toDestination();
    synth.triggerAttackRelease(nota, "0.1");
}

let rootButton = document.getElementById("select-root");
rootButton.addEventListener;

const button = document.getElementById('brillar-btn');

button.addEventListener('click', () => {
    button.classList.add('brillar');

    // Eliminar la clase de brillo después de 500ms para volver al estado original
    setTimeout(() => {
        button.classList.remove('brillar');
    }, 500);
});