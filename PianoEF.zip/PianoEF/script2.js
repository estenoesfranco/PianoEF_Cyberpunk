document.addEventListener("DOMContentLoaded", () => {
    let secuencia;
    function mostrarLetraNota(nota) {
        const noteDisplay = document.getElementById("noteDisplay");
        noteDisplay.textContent = nota;
        noteDisplay.className = "";

        noteDisplay.classList.add(`note-${nota.toLowerCase()}`);
    }

    function reproducirMusica() {
        const synth = new Tone.Synth().toDestination();

        const notas = ["C4", "B3", "A3", "G3", "F3", "E3", "D3", "C3"];
        secuencia = new Tone.Sequence((tiempo, nota) => {
            synth.triggerAttackRelease(nota, "8n", tiempo);
            mostrarLetraNota(nota);
        }, notas).start(0);

        Tone.Transport.bpm.value = 120;
        Tone.Transport.loop = true;
        Tone.Transport.loopEnd = "4m";
        Tone.Transport.start();

        setTimeout(() => {
            detenerMusica();
        }, 10000);
    }

    function detenerMusica() {
        Tone.Transport.stop();
    }

    const playButton = document.getElementById("playButton");
    playButton.addEventListener("click", reproducirMusica);
});

function reproducirNota(nota) {
    const synth = new Tone.Synth().toDestination();
    synth.triggerAttackRelease(nota, "0.0");
}

let rootButton = document.getElementById("select-root");
rootButton.addEventListener;
